#!/usr/bin/env python3
"""Reprojects world_map.json from equirectangular (flat, stretched near the poles) to Miller cylindrical."""
import json, math, re, sys
src = sys.argv[1] if len(sys.argv) > 1 else "world_map.json"
m = json.load(open(src))
if m["proj"].get("type") == "miller":
    sys.exit("already Miller - nothing to do")
S = 1080 / (2 * math.pi)                      # px per radian
my = lambda la: 1.25 * math.log(math.tan(math.pi / 4 + 0.4 * math.radians(la)))
TOP = my(84.0); BOT = my(-58.0)
H = round((TOP - BOT) * S, 1)
old = m["proj"]
def fwd(x, y):                                # old px -> new px
    lon = x / old["s"] + old["lon0"]; lat = old["lat1"] - y / old["s"]
    return (lon - old["lon0"]) * math.pi / 180 * S, (TOP - my(max(-89.9, min(89.9, lat)))) * S
tok = re.compile(r"([MLZ])|(-?\d+\.?\d*),(-?\d+\.?\d*)")
def conv(d):
    out = []
    for c, a, b in tok.findall(d):
        if c: out.append(c)
        else:
            x, y = fwd(float(a), float(b)); out.append("%.2f,%.2f" % (x, y))
    return "".join(out)
def shape(s):
    if s.get("d"):
        pts = [tuple(map(float, p.split(","))) for p in re.findall(r"-?\d+\.?\d*,-?\d+\.?\d*", conv(s["d"]))]
        s["d"] = conv(s["d"])
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        s["bbox"] = [round(min(xs), 1), round(min(ys), 1), round(max(xs), 1), round(max(ys), 1)]
    if s.get("marker"): s["marker"] = [round(v, 2) for v in fwd(*s["marker"])]
for s in m["states"]: shape(s)
for L in m.get("layers", []):
    for s in L["states"]: shape(s)
m["w"], m["h"] = 1080, H
m["proj"] = {"type": "miller", "lon0": -180.0, "s": S, "yTop": TOP, "latTop": 84.0, "latBot": -58.0}
json.dump(m, open(src, "w"), separators=(",", ":"))
print("reprojected: %dx%s px, aspect %.2f:1" % (1080, H, 1080 / H))
